/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package classe5;

import interface5.FaxMachine;

/**
 *
 * @author Kayque de Freitas <kayquefreitas08@gmail.com>
 * @data 16/02/2025
 * @brief Class FaxMachineImpl
 */
public class FaxMachineImpl implements FaxMachine {
    public void fax() {
        System.out.println("Faxing...");
    }
}
